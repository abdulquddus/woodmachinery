<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name;
?>

<div class="row carousel-holder">

                    <div>
                        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                            <ol class="carousel-indicators">
                                <li data-target="#carousel-example-generic" data-slide-to="0" class=""></li>
                                <li data-target="#carousel-example-generic" data-slide-to="1" class="active"></li>
                                <li data-target="#carousel-example-generic" data-slide-to="2" class=""></li>
								<li data-target="#carousel-example-generic" data-slide-to="3" class=""></li>
								<li data-target="#carousel-example-generic" data-slide-to="4" class=""></li>
                            </ol>
                            <div class="carousel-inner">
                                  <?php $datas= Banner::model()->findAll(); 
									$i=0;
									foreach($datas as $data)
									{
                                                                            
                                                                            if($i==0) {
                                ?>
                                <div class="item active ">
                                    <img class="slide-image" src="<?php echo Yii::app()->baseUrl ?>/banner/<?php echo $data['image'] ?>" alt="">
                                </div>
                                                                        <?php
                                                                        }
                                                                        else 
                                                                        { ?>                                                                            
                    <div class="item ">
                                    <img class="slide-image" src="<?php echo Yii::app()->baseUrl ?>/banner/<?php echo $data['image'] ?>" alt="">
                                </div>
                                
                                                                        <?php   } 
                                                                        
                                                                        $i++;
                                                                        } ?>

                               
                            </div>
                            <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                                <span class="glyphicon glyphicon-chevron-left"></span>
                            </a>
                            <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                                <span class="glyphicon glyphicon-chevron-right"></span>
                            </a>
                        </div>
                    </div>

                </div>

    <div class="container">

        <div class="row">

            

            <div class="col-md-9">
                   
                 <div class="contentheadingwrapper">
                     <div class="contentheading">New England's #1 Woodworking Sales and Service Professionals !</div>
                 </div>

                
                <div class="featuredmainwrapper">
                     <div class="featuredwrapper">Featured Equipment</div>
                     <div class="show">
                         <form>
                              <select>
                                     <option>Show 10</option>
                              </select>
                         </form>
                     </div>
                 </div>
                 
                <div class="row">
     <?php //$neweq= Equipment::model()->findAllByAttributes(array('status'=>1),array('order'=>'id DESC'));
                                           $sql="SELECT * FROM `equipment`  e , eq_images img WHERE e.status=1 and e.id=img.id_equipment and img.is_main=1 and is_featured=1 ";
                        $neweq = Yii::app()->db->createCommand($sql)->queryAll();
 foreach ($neweq as $newe) {  ?>
                    <div class="col-sm-2">
                        <div class="thumbnail">
                            <img src="<?php echo Yii::app()->baseUrl ?>/upload/images/small_<?php echo $newe['image_large'] ?>" alt="<?php echo $newe['name'] ?>">
							<div class="caption">
								<h6><strong><?php echo $newe['name'] ?></strong></h6>
								<p><a target="_blank" href="index.php/web/equipment?id=<?php echo $newe['id_equipment'] ?>">Details ></a></p>
							</div>
						</div>
                    </div> 
                      
 <?php } ?>

                               
                </div>
                
                <div class="col-sm-3">
    <a target="_blank" href="http://virtual-developers.com/sibghatprojects/akins/index.php/web/Listing/featured">View more NEW Equipment></a></p>
               
                </div>
                
                <div class="slidemainwrapper">
                     <div class="slider4">
                         <?php $datas= Manufacturer::model()->findAll(); 
									$j=0;
									foreach($datas as $data)
									{
                                                                            
                                                                            if($j==0) {
                                ?>
                          <div class="slide"><img src="<?php echo Yii::app()->baseUrl ?>/logos/<?php echo $data['image_logo'] ?>"></div>
                                                             <?php
                                                                        }
                                                                        else 
                                                                        { ?>
                          <div class="slide"><img src="<?php echo Yii::app()->baseUrl ?>/logos/<?php echo $data['image_logo'] ?>"></div>
                                                <?php   } 
                                                                        
                                                                        $j++;
                                                                        } ?>
  
  
                    </div>
                    
   <script>
  jnon(document).ready(function($){
  $('.slider4').bxSlider({
    slideWidth: 100,
    minSlides: 1,
    maxSlides: 6,
    moveSlides: 1,
    slideMargin: 10
  });
});
</script>
                 </div>
                 
                 
                 
                 
                 <div class="row">
                  <div class="newequip">
                   <div class="featuredmainwrapper">
                     <div class="featuredwrapper">Featured NEW Equipment</div>
                 </div>
<?php //$neweq= Equipment::model()->findAllByAttributes(array('status'=>1),array('order'=>'id DESC'));
                                           $sql="SELECT * FROM `equipment`  e , eq_images img WHERE e.status=1 and e.id=img.id_equipment and img.is_main=1 and is_featured=1 order by e.id DESC limit 3";
                        $neweq = Yii::app()->db->createCommand($sql)->queryAll();
 foreach ($neweq as $newe) {  ?>
                   <div class="col-sm-4 newcol-lg-4 col-md-4">
                        <div class="thumbnail">
                                  <img src="<?php echo Yii::app()->baseUrl ?>/upload/images/small_<?php echo $newe['image_large'] ?>" alt="<?php echo $newe['name'] ?>">
							<div class="caption">
								<p><a target="_blank" href="index.php/web/equipment?id=<?php echo $newe['id_equipment'] ?>">Details ></a></p>
							</div>
						</div>
                    </div> 
                      
 <?php } ?>
                    
                    <div class="col-sm-3">
                   <a target="_blank" href="#">View more NEW Equipment></a></p>
                </div>
               
                  </div>  
                  
                  
                  <div class="soldequip">
                   <div class="featuredmainwrapper">
                     <div class="featuredwrapper">Recently SOLD Equipment</div>
                 </div>

                      <?php //$neweq= Equipment::model()->findAllByAttributes(array('status'=>1),array('order'=>'id DESC'));
                                           $sql="SELECT * FROM `equipment`  e , eq_images img WHERE e.status=1 and e.id=img.id_equipment and img.is_main=1 and sold_status=1 order by e.id DESC ";
                        $neweq = Yii::app()->db->createCommand($sql)->queryAll();
 foreach ($neweq as $newe) {  ?>
                   <div class="col-sm-4 new2col-lg-4 col-md-4 " >
                     <div class="soldimg"><img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/newarrival/sold.png" /></div>
                      
                        <div class="thumbnail">
                               <img src="<?php echo Yii::app()->baseUrl ?>/upload/images/small_<?php echo $newe['image_large'] ?>" alt="<?php echo $newe['name'] ?>">
							<div class="caption">
								<h6><strong><?php echo $newe['name'] ?></strong></h6>
								<p><a target="_blank" href="index.php/web/equipment?id=<?php echo $newe['id'] ?>">Details ></a></p>
							</div>
						</div>
                    </div> 
                      
 <?php } ?>
                      
                      
                  <div class="col-sm-3">
                    <a target="_blank" href="http://virtual-developers.com/sibghatprojects/akins/index.php/web/Listing/sold">View Recently SOLD Equipment></a></p>
               </div>
               
                  </div>

                    
                 </div>
                 
                 
                
                
                 
                  

                   

            </div>
   <?php echo $this->renderPartial('_siderbar'); ?> 

        </div>

    </div>
    <!-- /.container -->