<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name;
?>

<div class="row carousel-holder">

                    <div>
                        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                            <ol class="carousel-indicators">
                                <li data-target="#carousel-example-generic" data-slide-to="0" class=""></li>
                                <li data-target="#carousel-example-generic" data-slide-to="1" class="active"></li>
                                <li data-target="#carousel-example-generic" data-slide-to="2" class=""></li>
								<li data-target="#carousel-example-generic" data-slide-to="3" class=""></li>
								<li data-target="#carousel-example-generic" data-slide-to="4" class=""></li>
                            </ol>
                            <div class="carousel-inner">
                                <div class="item">
                                    <img class="slide-image" src="<?php echo Yii::app()->baseUrl ?>/design/imgs/banners/1.jpg" alt="">
                                </div>
                                <div class="item active">
                                    <img class="slide-image" src="<?php echo Yii::app()->baseUrl ?>/design/imgs/banners/2.jpg" alt="">
                                </div>
                                <div class="item">
                                    <img class="slide-image" src="<?php echo Yii::app()->baseUrl ?>/design/imgs/banners/3.jpg" alt="">
                                </div>
								<div class="item">
                                    <img class="slide-image" src="<?php echo Yii::app()->baseUrl ?>/design/imgs/banners/4.jpg" alt="">
                                </div>
								<div class="item">
                                    <img class="slide-image" src="<?php echo Yii::app()->baseUrl ?>/design/imgs/banners/5.jpg" alt="">
                                </div>
                            </div>
                            <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                                <span class="glyphicon glyphicon-chevron-left"></span>
                            </a>
                            <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                                <span class="glyphicon glyphicon-chevron-right"></span>
                            </a>
                        </div>
                    </div>

                </div>

    <div class="container">

        <div class="row">

            

            <div class="col-md-9">
                   
                 <div class="contentheadingwrapper">
                     <div class="contentheading">New England's #1 Woodworking Sales and Service Professionals !</div>
                 </div>

                
                <div class="featuredmainwrapper">
                     <div class="featuredwrapper">Featured Equipment</div>
                     <div class="show">
                         <form>
                              <select>
                                     <option>Show 10</option>
                              </select>
                         </form>
                     </div>
                 </div>
                 
                <div class="row">

                    <div class="col-sm-2">
                        <div class="thumbnail">
                            <img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/products/p1.jpg" alt="">
							<div class="caption">
								<h6><strong>First Product</strong></h6>
								<p><a target="_blank" href="#">Details ></a></p>
							</div>
						</div>
                    </div>
					

                    <div class="col-sm-2">
                        <div class="thumbnail">
                            <img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/products/p2.jpg" alt="">
                            <div class="caption">
								<h6><strong>First Product</strong></h6>
								<p><a target="_blank" href="#">Details ></a></p>
							</div>
                        </div>
                    </div>

                    <div class="col-sm-2">
                        <div class="thumbnail">
                            <img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/products/p3.jpg" alt="">
                            <div class="caption">
								<h6><strong>First Product</strong></h6>
								<p><a target="_blank" href="#">Details ></a></p>
							</div>
                        </div>
                    </div>

                    <div class="col-sm-2">
                        <div class="thumbnail">
                            <img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/products/p4.jpg" alt="">
                            <div class="caption">
								<h6><strong>First Product</strong></h6>
								<p><a target="_blank" href="#">Details ></a></p>
							</div>
                        </div>
                    </div>

                    <div class="col-sm-2">
                        <div class="thumbnail">
                            <img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/products/p5.jpg" alt="">
                            <div class="caption">
								<h6><strong>First Product</strong></h6>
								<p><a target="_blank" href="#">Details ></a></p>
							</div>
                        </div>
                    </div>
					
					<div class="col-sm-2">
                        <div class="thumbnail">
                            <img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/products/p6.jpg" alt="">
                            <div class="caption">
								<h6><strong>First Product</strong></h6>
								<p><a target="_blank" href="#">Details ></a></p>
							</div>
                        </div>
                    </div>
					
					<div class="col-sm-2">
                        <div class="thumbnail">
                            <img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/products/p7.jpg" alt="">
                            <div class="caption">
								<h6><strong>First Product</strong></h6>
								<p><a target="_blank" href="#">Details ></a></p>
							</div>
                        </div>
                    </div>
					
					<div class="col-sm-2">
                        <div class="thumbnail">
                            <img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/products/p8.jpg" alt="">
                            <div class="caption">
								<h6><strong>First Product</strong></h6>
								<p><a target="_blank" href="#">Details ></a></p>
							</div>
                        </div>
                    </div>
					
					<div class="col-sm-2">
                        <div class="thumbnail">
                            <img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/products/p9.jpg" alt="">
                            <div class="caption">
								<h6><strong>First Product</strong></h6>
								<p><a target="_blank" href="#">Details ></a></p>
							</div>
                        </div>
                    </div>
					
					<div class="col-sm-2">
                        <div class="thumbnail">
                            <img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/products/p10.jpg" alt="">
							<div class="caption">
								<h6><strong>First Product</strong></h6>
								<p><a target="_blank" href="#">Details ></a></p>
							</div>
                        </div>
                    </div>                 
                </div>
                
                <div class="col-sm-3">
                   <a target="_blank" href="#">View more Featured Equipment></a></p>
                </div>
                
                <div class="slidemainwrapper">
                     <div class="slider4">
                          <div class="slide"><img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/logos/1.png"></div>
                          <div class="slide"><img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/logos/2.png"></div>
                          <div class="slide"><img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/logos/3.png"></div>
                          <div class="slide"><img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/logos/4.png"></div>
                          <div class="slide"><img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/logos/5.png"></div>
                          <div class="slide"><img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/logos/6.png"></div>
  
  
                    </div>
                    
   <script>
  jnon(document).ready(function($){
  $('.slider4').bxSlider({
    slideWidth: 100,
    minSlides: 1,
    maxSlides: 6,
    moveSlides: 1,
    slideMargin: 10
  });
});
</script>
                 </div>
                 
                 
                 
                 
                 <div class="row">
                  <div class="newequip">
                   <div class="featuredmainwrapper">
                     <div class="featuredwrapper">Featured NEW Equipment</div>
                 </div>

                    <div class="col-sm-4 newcol-lg-4 col-md-4">
                        <div class="thumbnail">
                            <img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/products/p1.jpg" alt="">
							<div class="caption">
								<h6><strong>First Product</strong></h6>
								<p><a target="_blank" href="#">Details ></a></p>
							</div>
						</div>
                    </div>
					

                    <div class="col-sm-4 newcol-lg-4 col-md-4">
                        <div class="thumbnail">
                            <img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/products/p2.jpg" alt="">
                            <div class="caption">
								<h6><strong>First Product</strong></h6>
								<p><a target="_blank" href="#">Details ></a></p>
							</div>
                        </div>
                    </div>

                    <div class="col-sm-4 newcol-lg-4 col-md-4">
                        <div class="thumbnail">
                            <img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/products/p3.jpg" alt="">
                            <div class="caption">
								<h6><strong>First Product</strong></h6>
								<p><a target="_blank" href="#">Details ></a></p>
							</div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                   <a target="_blank" href="#">View more NEW Equipment></a></p>
                </div>
               
                  </div>  
                  
                  
                  <div class="soldequip">
                   <div class="featuredmainwrapper">
                     <div class="featuredwrapper">Recently SOLD Equipment</div>
                 </div>

                     <div class="col-sm-4 new2col-lg-4 col-md-4 " >
                     <div class="soldimg"><img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/newarrival/sold.png" /></div>
                        <div class="thumbnail">
                        
                            <img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/products/p1.jpg" alt="">
							<div class="caption">
								<h6><strong>First Product</strong></h6>
								<p><a target="_blank" href="#">Details ></a></p>
							</div>
						</div>
                    </div>
					

                     <div class="col-sm-4 new2col-lg-4 col-md-4">
                     <div class="soldimg"><img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/newarrival/sold.png" /></div>
                        <div class="thumbnail">
                            <img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/products/p2.jpg" alt="">
                            <div class="caption">
								<h6><strong>First Product</strong></h6>
								<p><a target="_blank" href="#">Details ></a></p>
							</div>
                        </div>
                    </div>
                  <div class="col-sm-3">
                   <a target="_blank" href="#">View Recently SOLD Equipment></a></p>
                </div>
               
                  </div>

                    
                 </div>
                 
                 
                
                
                 
                  

                   

            </div>
<div class="col-lg-4">
                <div class="well">
                    <div class="input-group equip-search">
						<h5>Search Equipment</h5>
                        <input type="text" class="form-control">
                    </div>
					
					
					<div class="input-group cat-search">
						<h5>Category Search</h5>
						<select>
							<option selected>Select a Category</option>
							<option>XYZ</option>
						</select>
						<p><a href="#">Advance Search ></a></p>
					</div>
                    <!-- /input-group -->
					<div class="new-arrivals">
					<h4><strong>New Arrivals</strong></h4>
					<p><a href="#"><img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/thumbs/thum1.jpg"></a><strong>SCM T110A</strong></p>
					<p><a href="#"><img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/thumbs/thum2.jpg"></a><strong>Biesse LATO 23S</strong></p>
					<p><a href="#"><img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/thumbs/thum3.jpg"></a><strong>SAC PRIMA K970 </strong></p>
					<p><a href="#"><img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/thumbs/thum4.jpg"></a><strong>Hapfo AP5000M</strong></p>
					<p><a href="#"><img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/thumbs/thum5.jpg"></a><strong>SCM T101</strong></p>
					<p><a class="more" href="#">More ></a></p>
					</div>
					
					<div class="most-viewed">
					<div class="input-group cat-search">
						<select>
							<option selected>Most viewd</option>
							<option>XYZ</option>
						</select>
					</div>
					<p><a href="#"><img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/thumbs/thum1.jpg"></a><strong>SCM T110A</strong></p>
					<p><a href="#"><img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/thumbs/thum2.jpg"></a><strong>Biesse LATO 23S</strong></p>
					<p><a href="#"><img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/thumbs/thum3.jpg"></a><strong>SAC PRIMA K970 </strong></p>
					<p><a href="#"><img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/thumbs/thum4.jpg"></a><strong>Hapfo AP5000M</strong></p>
					<p><a href="#"><img src="<?php echo Yii::app()->baseUrl ?>/design/imgs/thumbs/thum5.jpg"></a><strong>SCM T101</strong></p>
					<p><a class="more" href="#">More ></a></p>
					</div>
                </div>
                <!-- /well -->
            </div>

        </div>

    </div>
    <!-- /.container -->