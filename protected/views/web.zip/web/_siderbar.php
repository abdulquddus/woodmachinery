      
<script>
function gotocate(valu) {
    
    if(valu!=0)
      
      window.location =' <?php echo Yii::app()->baseUrl ?>/index.php/web/category/id/'+valu;
      
    //alert(valu)
}

</script>
<div class="col-lg-4">
                <div class="well">
                    <div class="input-group equip-search">
						<h5>Search Equipment</h5>
                        <input type="text" class="form-control">
                    </div>
					
					
					<div class="input-group cat-search">
						<h5>Category Search</h5>
                                                <select onchange="gotocate(this.value)" id="cateid">
                                                    <option value="0" selected>Select a Category</option>
                                                        <?php $cates = Category::model()->findAllByAttributes(array('status'=>1)); 
                                                        
 foreach ($cates as $cate) {
    

                                                        ?>
                                                        <option value="<?php echo $cate['id'] ?>"><?php echo $cate['name'] ?> </option>
 <?php } ?>
                                                </select>
						<p><a href="<?php echo Yii::app()->baseUrl ?>/index.php/web/search">Advance Search ></a></p>
					</div>
                    <!-- /input-group -->
					<div class="new-arrivals">
					<h4><strong>New Arrivals</strong></h4>
                                        
                                        <?php //$neweq= Equipment::model()->findAllByAttributes(array('status'=>1),array('order'=>'id DESC'));
                                           $sql="SELECT * FROM `equipment`  e , eq_images img WHERE e.status=1 and e.id=img.id_equipment and img.is_main=1 order by e.id DESC limit 5";
                        $neweq = Yii::app()->db->createCommand($sql)->queryAll();
 foreach ($neweq as $newe) {
                                        ?>
					<p><a href="#"><img width="40" src="<?php echo Yii::app()->baseUrl ?>/upload/images/small_<?php echo $newe['image_large'] ?>"></a>
                                            <strong><?php echo $newe['name'] ?></strong></p>
                                        <?php } ?>
					<p><a class="more" href="http://virtual-developers.com/sibghatprojects/akins/index.php/web/Listing/new/1">More ></a></p>
					</div>
					
					<div class="most-viewed">
					<div class="input-group cat-search">
						<select>
							<option selected>Most viewed</option>
							<option>XYZ</option>
						</select>
					</div>
                        <?php                    
                                             $sql="SELECT * FROM `equipment`  e , eq_images img WHERE e.status=1 and e.id=img.id_equipment and img.is_main=1 order by hits DESC limit 5";
                        $neweq = Yii::app()->db->createCommand($sql)->queryAll();
 foreach ($neweq as $newe) {
                                        ?>
					<p><a href="#"><img width="40" src="<?php echo Yii::app()->baseUrl ?>/upload/images/small_<?php echo $newe['image_large'] ?>"></a>
                                            <strong><?php echo $newe['name'] ?></strong></p>
                                        <?php } ?>
					<p><a class="more" href="http://virtual-developers.com/sibghatprojects/akins/index.php/web/Listing/hits/1">More ></a></p>
					</div>
                </div>
                <!-- /well -->
            </div>