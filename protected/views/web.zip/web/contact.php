		
    <div class="container">

        <div class="row">

            
			<div class="slidemainwrapper">
                     <div class="slider4">
                           <?php $datas= Manufacturer::model()->findAll(); 
									$j=0;
									foreach($datas as $data)
									{
                                                                            
                                                                            if($j==0) {
                                ?>
                          <div class="slide"><img src="<?php echo Yii::app()->baseUrl ?>/logos/<?php echo $data['image_logo'] ?>"></div>
                                                             <?php
                                                                        }
                                                                        else 
                                                                        { ?>
                          <div class="slide"><img src="<?php echo Yii::app()->baseUrl ?>/logos/<?php echo $data['image_logo'] ?>"></div>
                                                <?php   } 
                                                                        
                                                                        $j++;
                                                                        } ?>
                    </div>
                </div>
            <div class="col-md-9">
				
                <h3 class="featuredwrapper2"><strong>Contact</strong></h3>
                 
                <div class="row">
                    		<form name="contact" action="contact" method="POST">
								<div class="submit-ticket contactform">
								<p><em>All fields are required</em></p>
								<label>Company Name: </label><input name="company" id="company" type="text" value=""><br>
								<label>Full Name: </label><input name="full_name" id="full_name"type="text" value=""><br>
								<label>Phone/Mobile: </label><input name="contact" id="contact" type="text" value=""><br>
								<label>Email: </label><input name="email" id="email" type="text" value=""><br>
								<label>Equip.Location: </label><input name="equiploc" id="equiploc" type="text" value=""><br><br>
								<span><label>Type your message: </label><br>
									<textarea cols="41" rows="5" name="message" id="message" value="" class="para"></textarea></span><br>
                                            <!--	<label>Date: </label><input name="date" id="date" type="text" value=""><br>-->
<!--								<label>Status: </label><input name="status" id="status" type="text" value=""><br><br>-->
                                                                        
                                                                        <span>
								<input name="submit" type="submit" value="submit">
								</span>
								</div>
							</form>
						
					</div>
                 
            </div>
	
        </div>

    </div>
    <!-- /.container -->
	<script>
  jnon(document).ready(function($){
  $('.slider4').bxSlider({
    slideWidth: 100,
    minSlides: 1,
    maxSlides: 6,
    moveSlides: 1,
    slideMargin: 10
  });
});
</script>
