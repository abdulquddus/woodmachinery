<?php $this->pageTitle=Yii::app()->name;
?>


				
    <div class="container">

        <div class="row">

            
			<div class="slidemainwrapper">
                     <div class="slider4">
                          <?php $datas= Manufacturer::model()->findAll(); 
									$j=0;
									foreach($datas as $data)
									{
                                                                            
                                                                            if($j==0) {
                                ?>
                          <div class="slide"><img src="<?php echo Yii::app()->baseUrl ?>/logos/<?php echo $data['image_logo'] ?>"></div>
                                                             <?php
                                                                        }
                                                                        else 
                                                                        { ?>
                          <div class="slide"><img src="<?php echo Yii::app()->baseUrl ?>/logos/<?php echo $data['image_logo'] ?>"></div>
                                                <?php   } 
                                                                        
                                                                        $j++;
                                                                        } ?>
                    </div>
                </div>
            <div class="col-md-9">
				
                <h3 class="featuredwrapper2 news"><strong>Machinery News</strong></h3>
                 
                <div class="row">
                    <?php $datas= Blog::model()->findAll();$datas= blog::model()->findAllByAttributes(array('type'=>'2'),array('order'=>'id DESC')); 
                    foreach($datas as $data)
									{
                    ?>
					<div class="headline col-md-12">
                                            <div class="pull-left col-md-10"><a  href="<?php echo Yii::app()->baseUrl ?>/index.php/web/dblog/id/<?php echo $data['id'] ?>"><h5><strong><?php echo $data->date=date("d-m-Y",  strtotime($data->date)).'-'.$data['title']?> </a></strong></h5><p><?php echo substr($data['content'],0,150)?>.</p></div>
						<div class="pull-right col-md-2"><img src="<?php echo Yii::app()->baseUrl ?>/blogimgs/<?php echo $data['image'] ?>"></div>
					</div>
					<?php } ?>
				</div>
            </div>
			
<?php echo $this->renderPartial('_siderbar'); ?> 

	<?php // include("sidebar.php"); ?>

        </div>

    </div>
    <!-- /.container -->
	<script>
  jnon(document).ready(function($){
  $('.slider4').bxSlider({
    slideWidth: 100,
    minSlides: 1,
    maxSlides: 6,
    moveSlides: 1,
    slideMargin: 10
  });
});
</script>
