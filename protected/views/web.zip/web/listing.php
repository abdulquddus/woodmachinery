   
<?php // print_r($_GET); exit;

$where='';
if(isset($_GET['condition']))
{
$where.="AND `condition` = ".$_GET['condition'];    
}

if(isset($_GET['sold']))
{
$where.="AND `sold_status` = 1";    
}


if(isset($_GET['featured']))
{
$where.="AND `is_featured` = 1";    
}



$order='order by';
if(isset($_GET['hits']))
{
$order .= '  hits DESC ,';    
}

if(isset($_GET['new']))
{
$order .= '  e.id DESC ,';    
}





$order=rtrim($order,',');

if($order=='order by')
    $order='order by e.id';


 $sql="SELECT * FROM `equipment`  e , eq_images img WHERE e.status=1 and e.id=img.id_equipment and img.is_main=1  $where $order  ";
                        $neweq = Yii::app()->db->createCommand($sql)->queryAll();
                        
if(isset($_GET['id']))
{        $id=$_GET['id'];

$category= Category::model()->FindByPk($id);

}
?>
<div class="container">

        <div class="row">

            <?php echo $this->renderPartial('_manufactureslider'); ?> 

		
            <div class="col-md-9">
			
				
                <h3><?php //echo $category->name ?></h3>
                <div class="featuredmainwrapper">
                     <div class="featuredwrapper featuredwrapper2">Equipment Category</div>
                     <div class="show show2">
                         <form>
                              <select>
                                     <option>Show 10</option>
                              </select>
                         </form>
                     </div>
                 </div>
                 
                <div class="row">
              <?php //$neweq= Equipment::model()->findAllByAttributes(array('status'=>1),array('order'=>'id DESC'));
                                       //    $sql="SELECT * FROM `equipment`  e , eq_images img WHERE e.status=1 and e.id=img.id_equipment and img.is_main=1 and id_category=$category->id order by e.id DESC ";
                      //  $neweq = Yii::app()->db->createCommand($sql)->queryAll();
 foreach ($neweq as $newe) {  ?>
                    <div class="col-sm-2">
                        <div class="thumbnail">
                            <img src="<?php echo Yii::app()->baseUrl ?>/upload/images/main_<?php echo $newe['image_large'] ?>" alt="">
							<div class="caption">
								<h6><strong><?php echo $newe['name'] ?></strong></h6>
								<p><a target="_blank" href="equipment?id=<?php echo $newe['id_equipment'] ?>">Details ></a></p>
							</div>
						</div>
                    </div>
					
 <?php } ?>
                   
                </div>
                 
            </div>
<?php echo $this->renderPartial('_siderbar'); ?> 
        </div>

    </div>
    <!-- /.container -->
