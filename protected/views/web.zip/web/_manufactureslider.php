 
                <div class="slidemainwrapper">
                     <div class="slider4">
                         <?php $datas= Manufacturer::model()->findAll(); 
									$j=0;
									foreach($datas as $data)
									{
                                                                            
                                                                            if($j==0) {
                                ?>
                          <div class="slide"><img src="<?php echo Yii::app()->baseUrl ?>/logos/<?php echo $data['image_logo'] ?>"></div>
                                                             <?php
                                                                        }
                                                                        else 
                                                                        { ?>
                          <div class="slide"><img src="<?php echo Yii::app()->baseUrl ?>/logos/<?php echo $data['image_logo'] ?>"></div>
                                                <?php   } 
                                                                        
                                                                        $j++;
                                                                        } ?>
  
  
                    </div>
                    
   <script>
  jnon(document).ready(function($){
  $('.slider4').bxSlider({
    slideWidth: 100,
    minSlides: 1,
    maxSlides: 6,
    moveSlides: 1,
    slideMargin: 10
  });
});
</script>
                 </div>