		
    <div class="container">

        <div class="row">

            
			<div class="slidemainwrapper">
                     <div class="slider4">
                           <?php $datas= Manufacturer::model()->findAll(); 
									$j=0;
									foreach($datas as $data)
									{
                                                                            
                                                                            if($j==0) {
                                ?>
                          <div class="slide"><img src="<?php echo Yii::app()->baseUrl ?>/logos/<?php echo $data['image_logo'] ?>"></div>
                                                             <?php
                                                                        }
                                                                        else 
                                                                        { ?>
                          <div class="slide"><img src="<?php echo Yii::app()->baseUrl ?>/logos/<?php echo $data['image_logo'] ?>"></div>
                                                <?php   } 
                                                                        
                                                                        $j++;
                                                                        } ?>
                    </div>
                </div>
            <div class="col-md-9">
				
                <h3 class="featuredwrapper2"><strong>Advance Search</strong></h3>
                 
               <div class="row">
                    		<form name="search-advance" method="post" action="">
								<div class="submit-ticket callnow">	
								<label>Search by Product Name: </label><input name="product-search" value="" type="text"><br>
								<label class="top10">Search by Year: </label><input name="year-search" value="" type="text"><br>
								<label class="top10">Select Manufacturer: </label>
									<select name="manufacturer">
										<option value="" selected="">--Select--</option>
										<option value="">Cantext</option>
										<option value="">Belfab</option>
									</select><br>
								<label class="top10">Select Model: </label>
									<select name="model">
										<option value="" selected="">--Select--</option>
										<option value="">NT-610EL</option>
										<option value="">Sandya 1S</option>
									</select><br>								
								<label class=" top10">Select Condition: </label>
									<select name="equip-choice">
										<option value="" selected="">--Select--</option>
										<option value="">New Equipment</option>
										<option value="">Used Equipment</option>
									</select><br>
								
								<label class="top10">Select Category: </label>
									<select name="search-cat">
										<option value="" selected="">--Select--</option>
										<option value="">Category 1</option>
										<option value="">Category 2</option>
									</select><br>
								<span>
								<input name="submit" value="Search" type="submit">
								</span>
								</div>
							</form>
					</div>
                 
            </div>
	

<?php echo $this->renderPartial('_siderbar'); ?> 

	<?php // include("sidebar.php"); ?>


        </div>

    </div>
    <!-- /.container -->
	<script>
  jnon(document).ready(function($){
  $('.slider4').bxSlider({
    slideWidth: 100,
    minSlides: 1,
    maxSlides: 6,
    moveSlides: 1,
    slideMargin: 10
  });
});
</script>
