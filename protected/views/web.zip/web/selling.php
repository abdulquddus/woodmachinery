			
    <div class="container">

        <div class="row">

            
			<div class="slidemainwrapper">
                     <div class="slider4">
                           <?php $datas= Manufacturer::model()->findAll(); 
									$j=0;
									foreach($datas as $data)
									{
                                                                            
                                                                            if($j==0) {
                                ?>
                          <div class="slide"><img src="<?php echo Yii::app()->baseUrl ?>/logos/<?php echo $data['image_logo'] ?>"></div>
                                                             <?php
                                                                        }
                                                                        else 
                                                                        { ?>
                          <div class="slide"><img src="<?php echo Yii::app()->baseUrl ?>/logos/<?php echo $data['image_logo'] ?>"></div>
                                                <?php   } 
                                                                        
                                                                        $j++;
                                                                        } ?>
                    </div>
                </div>
            <div class="col-md-9">
				
                <h3 class="featuredwrapper2"><strong>Evaluation for Selling Equipment</strong></h3>
                 
                <div class="row">
                    		<form enctype="multipart/form-data" name="selling" action="selling" method="POST">
								<div class="submit-ticket sellingForm">
								<p><em>All fields are required</em></p>
								<label>Company Name: </label><input name="company" id="company" type="text" value=""><br>
								<label>Full Name: </label><input name="full_name" id="full_name" type="text" value=""><br>
								<label>Phone/Mobile: </label><input name="contact" id="contact" type="text" value=""><br>
								<label>Email: </label><input name="email" type="text" value=""><br>
								<label>Equip.Location: </label><input name="eq_location" id="eq_location" type="text" value=""><br>
								<label class="ticket-priority para">Priority of Service Need: </label>
                                                                <select name="priority" id="priority">
										<option value="" selected>Select Priority</option>
										<option value="">ABC</option>
									</select><br>
								<p class="para">Upload Photos</p>
								<input name="image" id="image" type="file" class="para">
								<p class="addphoto"><a href="#" class="para">Add another photo+</a></p>
								<p class="para">Please Describe The Equipment You Want To Sell:</p>
								<textarea cols="41" rows="5" name="details" id="details" value="" class="para"></textarea><br>
								<label>Asking Price <sub>(if any)</sub> </label><input name="ask_price" id="ask_price" type="text" value=""><br>	
								<span>
								<input name="selling" type="submit" value="submit">
								</span>
								</div>
							</form>
						
					</div>
                 
            </div>
		<?php echo $this->renderPartial('_siderbar'); ?> 

	<?php // include("sidebar.php"); ?>	
			

        </div>

    </div>
    <!-- /.container -->
	<script>
  jnon(document).ready(function($){
  $('.slider4').bxSlider({
    slideWidth: 100,
    minSlides: 1,
    maxSlides: 6,
    moveSlides: 1,
    slideMargin: 10
  });
});
</script>
